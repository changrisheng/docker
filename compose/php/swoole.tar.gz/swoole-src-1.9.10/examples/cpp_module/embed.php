<?php
class Test
{
	public $name = "Rango";

	function getName()
	{
		return $this->name;
	}
}
